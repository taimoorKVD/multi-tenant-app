export * from './permission.entity';
