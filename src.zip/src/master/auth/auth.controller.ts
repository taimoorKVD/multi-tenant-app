import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { MasterAuthService } from './auth.service';
import { LoginDto } from './dto';

@Controller('master')
export class MasterAuthController {
  constructor(private readonly authService: MasterAuthService) {}

  // @Post('login')
  // async login(@Body() dto: LoginDto) {
  //   return this.authService.login(dto);
  // }

  @Post('login')
  async login(@Body() loginDto: LoginDto) {
    return this.authService.login(loginDto);
  }

  // @Post('register')
  // async register(
  //   @Body() body: { first_name: string; last_name: string; email: string; password: string },
  // ) {
  //   return this.authService.register(body);
  // }

  /** GET /auth/user (Protected) */
  @UseGuards(AuthGuard)
  @Get('auth/user')
  async getUser(@Req() req: Request) {
    return this.authService.getProfile(req['user'].id);
  }
}
