export * from './role.entity';
