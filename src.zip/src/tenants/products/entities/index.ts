export * from './product.entity';
